package Sdlc;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Fenetre extends JFrame{
	  private String question;
	  
	
	  private JPanel pan = new JPanel();
	  private JButton yes = new JButton("Yes");
	  private JButton no = new JButton("No");
	  private static JButton next = new JButton("-->");
	  private JTextArea tquestion = new JTextArea(question);
	  private static JTextArea hello = new JTextArea("Hello !!! \n this programe is used to identify the appropriate SDLC moddel for your project, \njust by answering questions!");
	
	  public Fenetre(){
		  
	    this.setTitle("Animation");
	    this.setSize(800, 300);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null);
	    //Ajout du bouton à notre content pane
	    //pan.add(tquestion);
	    //pan.add(yes);
	    //pan.add(no);
	    this.setContentPane(pan);
    	this.setVisible(true);
	  }     
	  public void setQuestion(String question) {
		  this.question = question;
	  }
	  public static void main(String[] args) {
	  	Fenetre f=new Fenetre();
	  	
	  	
	  	f.add(hello);
	  	f.add(next);
	  	String name = "TEST";
		HashMap<String, Integer> SdlcM = new HashMap<String,Integer>();
		SdlcM.put("Watter Fall", 0); // "Watter Fall","Vshaped","Itterative","Agile","Spirale","Prototype"
		SdlcM.put("Vshaped", 0);
		SdlcM.put("Itterative", 0);
		SdlcM.put("Agile", 0);
		SdlcM.put("Spirale", 0);
		SdlcM.put("Prototype", 0);
		
		
		String[] questions=new String[7];
		questions[0]="Does your Client knows what he want ?";
		questions[1]="is "+name+" a high risk project ?";
		questions[2]="Are there going to be any changments during the process or it's going to be fixed ?";
		questions[3]="Is the technology used is well understood by the project team ?";
		questions[4]="Is "+name+" a high budget project ?";
		questions[5]="Does "+name +" have a lot of screens ?";
		questions[6]="can your team co-locate ?";
		
		
		
		
		
	
		
		
		
		
		
  }
  
}