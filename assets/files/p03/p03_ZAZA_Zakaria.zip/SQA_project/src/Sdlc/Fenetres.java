package Sdlc;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Fenetres extends JFrame{
	private static final long serialVersionUID = 1L;
	CardLayout cl = new CardLayout();
	JPanel content = new JPanel();
	String[] listContent = {"Hello", "Q1","Q2","Q3","Q4","Q5","Q6","Q7", "Result"};
	JButton next = new JButton("-->");JTextArea hello = new JTextArea("Hello !!! \n this programe is used to identify the appropriate SDLC moddel for your project, \njust by answering questions!");
	
	int indice = 0;
	
public void setquestion(JPanel Question, String qst,int [] tab){
	Question.setBackground(Color.red);
	
	JTextArea tquestion = new JTextArea(qst);
	Question.add(tquestion);
	
	JButton yes = new JButton("Yes");
	JButton no = new JButton("No");
	
	Question.add(yes);
	Question.add(no);
	
	indice ++;
	
	yes.addActionListener(new ActionListener(){
  		public void actionPerformed(ActionEvent event){
  			tab[indice]=1;
			cl.next(content);
  		}
  	});
  	
	no.addActionListener(new ActionListener(){
  		public void actionPerformed(ActionEvent event){
  			tab[indice]=0;
  			cl.next(content);
  		}	
  	});
	
}	

public Fenetres(){
	
    this.setTitle("CardLayout");
    this.setSize(800, 300);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLocationRelativeTo(null);
    JPanel card1 = new JPanel();
    card1.setBackground(Color.blue);	
    card1.add(hello);
  	card1.add(next);
  	
  	next.addActionListener(new ActionListener(){
  		public void actionPerformed(ActionEvent event){
  			cl.next(content);
  		}
  		
  	});
  	
  	
  	int[] tab = new int[10];
  	String name = "TEST";
  	
    JPanel Q1 = new JPanel();
    setquestion(Q1,"Does your Client knows what he want ?",tab);
    
    JPanel Q2 = new JPanel();
    setquestion(Q2,"is "+name+" a high risk project ?",tab);
    
    JPanel Q3 = new JPanel();
    setquestion(Q3,"Are there going to be any changments during the process or it's going to be fixed ?",tab);
    
    JPanel Q4 = new JPanel();
    setquestion(Q4,"Is the technology used is well understood by the project team ?",tab);
    
    JPanel Q5 = new JPanel();
    setquestion(Q5,"Is "+name+" a high budget project ?",tab);
    
    JPanel Q6 = new JPanel();
    setquestion(Q6,"Does "+name +" have a lot of screens ?",tab);
    
    JPanel Q7 = new JPanel();
    setquestion(Q7,"can your team co-locate ?",tab);
    JPanel result = new JPanel();
    result.setBackground(Color.green);
    
    new Analyse();
    
    String res = Analyse.result(Analyse.analys(tab));
    JTextArea textResult = new JTextArea(res);
    
    result.add(textResult);
    
    content.setLayout(cl);
    
    content.add(card1, listContent[0]);
    
    content.add(Q1, listContent[1]);
    content.add(Q2, listContent[2]);
    content.add(Q3, listContent[3]);
    content.add(Q4, listContent[4]);
    content.add(Q5, listContent[5]);
    content.add(Q6, listContent[6]);
    content.add(Q7, listContent[7]);
    
    content.add(result, listContent[8]);
    
    this.getContentPane().add(content, BorderLayout.CENTER);
    this.setVisible(true);
  }	
  
  
  
  
  
  
  
  
  
  
  public static void main(String[] args) {
	  
	  
	  	 new Fenetres();
	  	
	  	
  }
}