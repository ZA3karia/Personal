package Sdlc;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class Analyse {
	static HashMap<String, Integer> sdlcM;
	
	public Analyse() {
		sdlcM = new HashMap<String,Integer>();
		sdlcM.put("Watter Fall", 0); // "Watter Fall","Vshaped","Itterative","Agile","Spirale","Prototype"
		sdlcM.put("Vshaped", 0);
		sdlcM.put("Itterative", 0);
		sdlcM.put("Agile", 0);
		sdlcM.put("Spirale", 0);
		sdlcM.put("Prototype", 0);
	}



	public static void print() {
		System.out.println("\nThe SDLC models ranked by points \n");
		for (Entry<String, Integer> entry : sdlcM.entrySet()) {
		    System.out.println(entry.getKey() + " at the value of : " + entry.getValue());
		}
		
	}

	public static String result(HashMap<String, Integer> sdlcM) {
		String S = "\nThe SDLC models ranked by points \n";
		for (Entry<String, Integer> entry : sdlcM.entrySet()) {
		    S = S + entry.getKey() + " at the value of : " + entry.getValue() +"\n";
		}
		return S;
	}

	public static HashMap<String, Integer> analys(int[] tab) {
		int i=0;
		//question 1 // Does your Client knows what he want ?
		if(tab[i]== 1) {
			sdlcM.replace("Watter Fall", sdlcM.get("Watter Fall")+ 1 );
			sdlcM.replace("Vshaped", sdlcM.get("Vshaped")+ 1 );
			sdlcM.replace("Itterative", sdlcM.get("Itterative")+ 1 );
		}
		else {
			sdlcM.replace("Agile", sdlcM.get("Agile")+ 1 );
			sdlcM.replace("Spirale", sdlcM.get("Spirale")+ 1 );
			sdlcM.replace("Prototype", sdlcM.get("Prototype")+ 1 );
		}
		i++;
		
		//question 2 // is "+name+" a high risk project ?
		if(tab[i]== 1) {
			sdlcM.replace("Agile", sdlcM.get("Agile")+ 1 );
			sdlcM.replace("Spirale", sdlcM.get("Spirale")+ 1 );
		}
		else {
			sdlcM.replace("Watter Fall", sdlcM.get("Watter Fall")+ 1 );
		}
		i++;
		
		//question  // Are there going to be any changments during the process or it's going to be fixed 
		if(tab[i]== 1) {
			sdlcM.replace("Itterative", sdlcM.get("Itterative")+ 1 );
			sdlcM.replace("Agile", sdlcM.get("Agile")+ 1 );
			sdlcM.replace("Spirale", sdlcM.get("Spirale")+ 1 );
		}
		else {
			sdlcM.replace("Watter Fall", sdlcM.get("Watter Fall")+ 1 );
			sdlcM.replace("Vshaped", sdlcM.get("Vshaped")+ 1 );		}
		i++;
		
		//question 1 // Is the technology used is well understood by the project team ?
		if(tab[i]== 1) {
			sdlcM.replace("Watter Fall", sdlcM.get("Watter Fall")+ 1 );
			sdlcM.replace("Vshaped", sdlcM.get("Vshaped")+ 1 );
		}
		else {
			sdlcM.replace("Itterative", sdlcM.get("Itterative")+ 2 );
			sdlcM.replace("Agile", sdlcM.get("Agile")+ 2 );
			sdlcM.replace("Spirale", sdlcM.get("Spirale")+ 1 );
		}
		i++;
		
		//question 1 // Is "+name+" a high budget project ?
		if(tab[i]== 1) {
			sdlcM.replace("Agile", sdlcM.get("Agile")+ 1 );
			sdlcM.replace("Watter Fall", sdlcM.get("Watter Fall")+ 1 );
			sdlcM.replace("Vshaped", sdlcM.get("Vshaped")+ 1 );
			sdlcM.replace("Itterative", sdlcM.get("Itterative")+ 1 );
		}
		else {
			sdlcM.replace("Spirale", sdlcM.get("Spirale")+ 3 );
		}
		i++;
		
		//question 1 // Does "+name +" have a lot of screens ?
		if(tab[i]== 1) {
			sdlcM.replace("Prototype", sdlcM.get("Prototype")+ 5 );
		}
		i++;
		
		//question 1 // can your team co-locate ?
		if(tab[i]== 1) {
			sdlcM.replace("Agile", sdlcM.get("Agile")+ 5 );}
		else {
			sdlcM.replace("Agile", 0 );
		}
		
		
		
		return sdlcM;
	}

}
